package com.capgemini.model.controller;

import com.capgemini.model.entity.Customer;
import com.capgemini.model.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

	@Autowired
	private CustomerService service;

	@PostMapping
	public Customer create(@RequestBody Customer c) {
		return service.create(c);
	}

	@GetMapping
	public List<Customer> getAll() {
		return service.getAll();
	}

	@GetMapping("/{id}")
	public Customer getById(@PathVariable int id) {
		return service.getById(id);
	}

	@PutMapping("/{id}")
	public Customer update(@PathVariable int id, @RequestBody Customer c) {
		return service.update(id, c);
	}

	@DeleteMapping("/{id}")
	public String delete(@PathVariable int id) {
		service.delete(id);
		return "Customer deleted successfully";
	}

	@GetMapping("/{id}/restore")
	public Customer restore(@PathVariable int id) {
		return service.restore(id);
	}
}