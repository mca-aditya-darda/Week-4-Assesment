package com.capgemini.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class RevenueDTO {
    private String customerName;
    private BigDecimal totalRevenue;
}