package com.capgemini.model.service;

import com.capgemini.model.dto.OrderDTO;
import com.capgemini.model.dto.RevenueDTO;
import com.capgemini.model.entity.Customer;
import com.capgemini.model.entity.Order;
import com.capgemini.model.exception.BadRequestException;
import com.capgemini.model.exception.ResourceNotFoundException;
import com.capgemini.model.repository.CustomerRepository;
import com.capgemini.model.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderService {

	@Autowired
	private OrderRepository orderRepo;

	@Autowired
	private CustomerRepository customerRepo;

	public Order placeOrder(int customerId, OrderDTO dto) {

		Customer c = customerRepo.findById(customerId)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found"));

		Order o = new Order();
		o.setProductName(dto.getProductName());
		o.setQuantity(dto.getQuantity());
		o.setPricePerUnit(dto.getPricePerUnit());
		o.setStatus(dto.getStatus());

		o.setTotalAmount(dto.getPricePerUnit().multiply(BigDecimal.valueOf(dto.getQuantity())));

		o.setCustomer(c);

		return orderRepo.save(o);
	}

	public Page<Order> getOrders(int customerId, String status, int page, int size) {

		Pageable pageable = PageRequest.of(page, size);

		if (status != null) {
			return orderRepo.findByCustomerCustomerIdAndStatus(customerId, status, pageable);
		}

		return orderRepo.findByCustomerCustomerId(customerId, pageable);
	}

	public Order cancel(int orderId) {
		Order o = orderRepo.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found"));

		if (o.getStatus().equals("SHIPPED") || o.getStatus().equals("DELIVERED")) {
			throw new BadRequestException("Cannot cancel an order with status " + o.getStatus());
		}

		o.setStatus("CANCELLED");
		return orderRepo.save(o);
	}

	public List<RevenueDTO> revenue() {
		return orderRepo.getRevenueSummary();
	}
}