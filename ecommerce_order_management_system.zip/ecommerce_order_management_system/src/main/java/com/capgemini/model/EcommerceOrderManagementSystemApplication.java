package com.capgemini.model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceOrderManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceOrderManagementSystemApplication.class, args);
	}

}
