package com.capgemini.model.controller;

import com.capgemini.model.dto.OrderDTO;
import com.capgemini.model.dto.RevenueDTO;
import com.capgemini.model.entity.Order;
import com.capgemini.model.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class OrderController {

	@Autowired
	private OrderService service;

	@PostMapping("/{customerId}/orders")
	public Order create(@PathVariable int customerId, @RequestBody OrderDTO dto) {
		return service.placeOrder(customerId, dto);
	}

	@GetMapping("/{customerId}/orders")
	public Page<Order> get(@PathVariable int customerId, @RequestParam(required = false) String status,
			@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "5") int size) {
		return service.getOrders(customerId, status, page, size);
	}

	@PatchMapping("/{customerId}/orders/{orderId}/cancel")
	public Order cancel(@PathVariable int customerId, @PathVariable int orderId) {
		return service.cancel(orderId);
	}

	@GetMapping("/revenue-summary")
	public List<RevenueDTO> revenue() {
		return service.revenue();
	}
}