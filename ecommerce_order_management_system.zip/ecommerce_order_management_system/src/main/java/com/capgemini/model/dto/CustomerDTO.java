package com.capgemini.model.dto;

import lombok.Data;

@Data
public class CustomerDTO {
    private Integer customerId;
    private String fullName;
    private String email;
    private String phone;
}