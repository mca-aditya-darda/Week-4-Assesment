package com.capgemini.model.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderDTO {
    private Integer orderId;
    private String productName;
    private Integer quantity;
    private BigDecimal pricePerUnit;
    private String status;
}